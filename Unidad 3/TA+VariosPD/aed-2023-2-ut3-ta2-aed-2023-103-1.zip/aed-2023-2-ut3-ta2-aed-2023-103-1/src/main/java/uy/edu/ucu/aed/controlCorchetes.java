package uy.edu.ucu.aed;

public class controlCorchetes {
    public boolean controlCorchetes(String[] listaEntradas){
        Lista <String> listaVerificar = new Lista<>();
        for(String i: listaEntradas){
            if (i.equals("{")){
                Nodo a = new Nodo(i, "{");
                listaVerificar.insertar(a);
            }
            else if (i.equals("}")){
                Nodo a = new Nodo(i, "}");
                if (listaVerificar.esVacia()){
                    return false;
                }
                else{
                    listaVerificar.eliminar(i);
                }
            }
        }
        if (listaVerificar.esVacia()){
            return true;
        }
        else{
            return false;
        }
    }
}
