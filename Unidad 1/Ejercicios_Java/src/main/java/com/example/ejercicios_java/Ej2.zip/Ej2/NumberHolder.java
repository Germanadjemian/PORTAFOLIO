package com.example.ejercicios_java.Ej2;

public class NumberHolder
{
    public int anInt;
    public float aFloat;
}
