package uy.edu.ucu.aed;

/**
 *
 * @author abadie
 */
public class Main {
    
    public static void main(String[] args){
        // TODO: 
        /**
         * Instanciar almacen
         * Agregar: productos y cantidades (altas.txt)
         * Emitir listado de productos y cantidades
         * Emitir valor de stock de todo el almacen
         * Vender: restar stock de productos indicado en ventas.txt
         * Emitir valor de stock de todo el almacen
         **/
        String[] archivo=ManejadorArchivosGenerico.leerArchivo("C:\\Users\\adjem\\OneDrive - Universidad Católica del Uruguay\\Algoritmos\\Unidad 3\\TA\\aed-2023-2-ut3-ta2-aed-2023-103-1\\src\\main\\java\\uy\\edu\\ucu\\aed\\altas.txt");

        for (int i=0;i<=archivo.length-1;i++){
            //FALTA HACER
        }
    }

}
