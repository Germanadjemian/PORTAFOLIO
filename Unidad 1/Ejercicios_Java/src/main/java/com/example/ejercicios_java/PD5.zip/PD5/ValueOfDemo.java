package com.example.ejercicios_java.PD5;
import  java.lang.Float;
/*
public class ValueOfDemo
{
    public static void main(String[] args) {
// this program requires two
// arguments on the command line
        if (args.length == 3) {
// convert strings to numbers
            float a = (Float.value (args[0])).floatValue();
            float b = (Float.valueOf(args[1])).float ();
// do some arithmetic
            System.out.println("a + b = " +
                    (a + b));
            System.out.println("a - b = " +
                    (a - b));
            System.out.println("a * b = " +
                    (a * b));
            System.out.println("a / b = " +
                    (a / b));
            System.out.println("a % b = " +
                    (a % b));
        } else {
            System.out.println("This program " +
                    "requires two command-line arguments.");
        }
    }
}
//El programa no funciona correctamente ya que tiene 2  errores (en las lineas 10 y 11 comentadas) y además no tiene por donde ingresaar los parámetros .
//Para modificar el programa para que los numeros fueran solo enteros positivos, debería ponerse de tipo int>0.
*/