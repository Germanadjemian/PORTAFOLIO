package com.example.ejercicios_java.PD6;

import java.util.ArrayList;

public class pruebas
{
    
    public static void main(String[] args)
    {
        ArrayList<String> pruebas= new ArrayList<>();//sin el new sale no inicializada.
        System.out.println(pruebas);

    /*public pruebas() {
        this.pruebas = new ArrayList<String>();
    }*/
    }
}
